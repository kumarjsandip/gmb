<?php $__env->startSection('content'); ?>

    
    <div class="col-md-3 col-sm-3 col-xs-12 second-row">
<div class="row">
        <h6><img class="iconc" src="<?php echo e(asset(url('public/icons/date.png'))); ?>" />Date</h6>
        <ul>
            <?php $__currentLoopData = $projectsc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $project->campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(asset(url('home/campain/create/detail/'.$project->id ))); ?>?campaign=<?php echo e($campaign->id); ?>"><i class="fas fa-circle"></i> <?php echo e($campaign->campaignname); ?> </a>
            <i onclick="campaigndelete(<?php echo e($campaign->id); ?>)" class="fas fa-trash-alt pull-right"></i>
        </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    </div>
    
   

<script>
    // Get the <datalist> and <input> elements.
    var dataList = document.getElementById('json-datalist');
    var input = document.getElementById('ajax');

    // Create a new XMLHttpRequest.
    var request = new XMLHttpRequest();

    // Handle state changes for the request.
    request.onreadystatechange = function (response) {
        if (request.readyState === 4) {
            if (request.status === 200) {
                // Parse the JSON
                var jsonOptions = JSON.parse(request.responseText);

                // Loop over the JSON array.
                jsonOptions.forEach(function (item) {
                    // Create a new <option> element.
                    var option = document.createElement('option');
                    // Set the value using the item in the JSON array.
                    option.value = item;
                    // Add the <option> element to the <datalist>.
                    dataList.appendChild(option);
                });

                // Update the placeholder text.
                input.placeholder = "e.g. datalist";
            } else {
                // An error occured :(
                input.placeholder = "Couldn't load datalist options :(";
            }
        }
    };


    $('#createproject').on('click', function () {
        var projectname = $(".projectname").val();

        var projectdata = {
            '_token': $("#token").val(),
            'projectname': $(".projectname").val(),
        };

        $.ajax({
            type: "POST",
            'data': projectdata,
            'url': "<?php echo url('home/project/create'); ?>",
            success: function (data) {
                $(".projectname").val('');
                $('.alert-success').text(data.success);
                $(".alert-success").show();
                $('#projectcreatemessage').hide();
                setTimeout(function () { $('.modal').modal('hide'); }, 1000);
                window.setTimeout(function () { location.reload() }, 1000)
            },
            error: function (data) {
                var errors = '';
                for (datos in data.responseJSON) {
                    errors += data.responseJSON[datos] + '<br>';
                }
                $('#projectcreatemessage').show().html(errors); //this is my div with messages
            }

        })
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>