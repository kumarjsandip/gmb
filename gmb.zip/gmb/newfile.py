
def main():
	print("This is check")
	return "This is check"

if __name__ == '__main__':
	main()