import sys

print "hello";