<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mashup extends Model
{
    //
}
