<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Projectcampaigntable extends Model
{
   
}
